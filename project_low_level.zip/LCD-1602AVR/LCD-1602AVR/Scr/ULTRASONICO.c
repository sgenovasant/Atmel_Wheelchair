/*
 * ULTRASONICO.c
 *
 * Created: 5/13/2023 10:59:59 PM
 *  Author: sgeno
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>

#define TRIG_PIN PB3
#define ECHO_PIN PB0

void ULTRASONIC_timer1()
{
	TCCR1B |= (1 << CS10);
}

uint16_t ULTRASONIC_Mesure()
{
	// Send trigger pulse
	PORTB &= ~(1 << TRIG_PIN);
	_delay_us(2);
	PORTB |= (1 << TRIG_PIN);
	_delay_us(10);
	PORTB &= ~(1 << TRIG_PIN);

	// Wait for echo
	while (!(PINB & (1 << ECHO_PIN)));
	TCNT1 = 0;

	// Measure echo pulse width
	while (PINB & (1 << ECHO_PIN));
	uint16_t pulse_width = TCNT1;
	return pulse_width/(58*2);
}

void ULTRASONIC_Init()
{
	DDRB |= (1 << TRIG_PIN);
	DDRB &= ~(1 << ECHO_PIN);
}