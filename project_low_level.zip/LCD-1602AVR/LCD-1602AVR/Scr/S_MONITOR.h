/*
 * S_MONITOR.h
 *
 * Created: 6/1/2023 2:18:36 AM
 *  Author: sgeno
 */ 


#ifndef S_MONITOR_H_
#define S_MONITOR_H_


void initSerial();
void serialTransmitChar(char data);
void serialPrint(const char* str);
char serialReceiveChar();
uint8_t receiveByte();
void transmitByte(uint8_t data);

#endif /* S_MONITOR_H_ */