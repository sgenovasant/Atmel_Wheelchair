/*
 * ADC_VALUE.c
 *
 * Created: 6/2/2023 9:44:41 PM
 *  Author: sgeno
 */ 

#include <avr/io.h>
#include <util/delay.h>


void ADC_Init()
{
	ADMUX = (1 << REFS0);
	ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

uint16_t ADC_Read(uint8_t channel)
{
	// Seleccionar canal de entrada y comenzar la conversi�n ADC
	ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);
	ADCSRA |= (1 << ADSC);

	while (ADCSRA & (1 << ADSC))
	;
	
	return ADC;
}
