/*
 * MPU6050_REG.h
 *
 * Created: 6/1/2023 9:23:06 PM
 *  Author: sgeno
 */ 


#ifndef MPU6050_REG_H_
#define MPU6050_REG_H_

#define ACC_X 0x3B
#define ACC_Y 0x3D
#define ACC_Z 0x3F
#define TEMPERATURE 0x41
#define GYRO_X 0X43
#define GYRO_Y 0X45
#define GYRO_Z 0X47

void I2C_Starter();
void MPU6050_Init();
int16_t MPU6050_ReadRawData(uint8_t reg);


#endif /* MPU6050_REG_H_ */