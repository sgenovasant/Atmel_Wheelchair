/*
 * SERVOMR.h
 *
 * Created: 4/12/2023 11:16:33 PM
 *  Author: sgeno
 */ 


#ifndef SERVOMR_H_
#define SERVOMR_H_

void SERVO_init();
void SERVO_ang(uint8_t axis);



#endif /* SERVOMR_H_ */