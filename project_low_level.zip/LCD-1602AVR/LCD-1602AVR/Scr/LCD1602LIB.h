/*
 * LCD_1602LIB.h
 *
 * Created: 5/13/2023 3:38:39 PM
 *  Author: sgeno
 */ 


#ifndef LCD1602LIB_H_
#define LCD1602LIB_H_
#endif /* LCD-1602LIB_H_ */

#define HOME 0x80

void LCD_Command( unsigned char cmnd );
void LCD_Char( unsigned char data );
void LCD_Init (void);
void LCD_String (char *str);
void LCD_String_xy (char row, char pos, char *str);
void LCD_Clear();
void LCD_Custom_Char (unsigned char loc, unsigned char *msg);
void LCD_Build_Char();

//SYSTEM ANIMATION
void STARTING_SYS();
void MODE_SELECT();
void STATIC_SYS();
void DINAMIC_X (char move);
void DINAMIC_Y (char movee);


