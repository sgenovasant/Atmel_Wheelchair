/*
 * ADC_VALUE.h
 *
 * Created: 6/2/2023 9:47:00 PM
 *  Author: sgeno
 */ 


#ifndef ADC_VALUE_H_
#define ADC_VALUE_H_

void ADC_Init();
uint16_t ADC_Read(uint8_t channel);


#endif /* ADC_VALUE_H_ */