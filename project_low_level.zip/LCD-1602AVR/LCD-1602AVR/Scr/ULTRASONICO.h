/*
 * ULTRASONICO.h
 *
 * Created: 5/13/2023 10:59:37 PM
 *  Author: sgeno
 */ 


#ifndef ULTRASONICO_H_
#define ULTRASONICO_H_

void ULTRASONIC_timer1();
unsigned int ULTRASONIC_Mesure();
void ULTRASONIC_Init();



#endif /* ULTRASONICO_H_ */