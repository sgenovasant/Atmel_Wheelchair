/*
 * S_MONITOR.c
 *
 * Created: 6/1/2023 2:17:23 AM
 *  Author: sgeno
 */ 

#include <avr/io.h>
#include <stdio.h>

#define F_CPU 16000000UL

#define BAUD_RATE 9600

void initSerial()
{
	// Calcular el valor del registro UBRR para la velocidad de transmisi�n deseada
	uint16_t ubrr = F_CPU / 16 / BAUD_RATE - 1;
	
	// Configurar la velocidad de transmisi�n serial
	UBRR0H = (ubrr >> 8);    // Registro de alta del UBRR
	UBRR0L = ubrr;           // Registro de baja del UBRR
	
	// Habilitar la transmisi�n y recepci�n serial
	UCSR0B = (1 << TXEN0) | (1 << RXEN0);
	
	// Establecer el tama�o de los caracteres a 8 bits
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

// Funci�n para transmitir un car�cter a trav�s del monitor serial
void serialTransmitChar(char data)
{
	// Esperar hasta que el registro de datos est� vac�o
	while (!(UCSR0A & (1 << UDRE0)));
	
	// Cargar el car�cter a transmitir en el registro de datos
	UDR0 = data;
}

// Funci�n para imprimir una cadena de caracteres en el monitor serial
void serialPrint(const char* str)
{
	// Iterar sobre la cadena de caracteres hasta encontrar el car�cter nulo
	for (int i = 0; str[i] != '\0'; i++)
	{
		// Transmitir cada car�cter de la cadena
		serialTransmitChar(str[i]);
	}
}

char serialReceiveChar()
{
	// Esperar hasta que se reciba un car�cter
	while (!(UCSR0A & (1 << RXC0)));
	
	// Leer el car�cter del registro de datos
	return UDR0;
}

uint8_t receiveByte()
{
	// Esperar hasta que se reciba un byte
	while (!(UCSR0A & (1 << RXC0)));
	
	// Leer y devolver el byte recibido
	return UDR0;
}

void transmitByte(uint8_t data)
{
	// Enviar el byte de datos
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = data;
}