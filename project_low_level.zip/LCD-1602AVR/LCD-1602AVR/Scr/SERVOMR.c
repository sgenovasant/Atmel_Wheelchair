/*
 * SERVOMR.c
 *
 * Created: 4/12/2023 6:32:25 PM
 *  Author: sgeno
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <math.h>
volatile uint16_t pmw_ang;

void SERVO_init()
{
// Configure PWM output pin (OC1A) as output
DDRB |= (1 << PB2);

// Configure Timer/Counter1 for PWM generation
TCCR1A |= (1 << COM1B1) | (1 << WGM11);
// Set up Timer/Counter1 for PWM generation
TCCR1B |= (1 << WGM13) | (1 << WGM12) | (1 << CS11); 
ICR1 = 40000; // PWM period = 20ms (at 16MHz and prescaler = 8)

OCR1B=3000;
}

void SERVO_ang(uint8_t axis)
{
	//there is a conversion error in the variable after 21-255
	//motion adjustment 40� to 140�
	if (axis>20)
	{
		pmw_ang=3800;
	} 
	else
	{
		pmw_ang= (80*axis)+2200;
	}
	
	OCR1B=pmw_ang;

}

