/*
 * MASTER_I2C.h
 *
 * Created: 5/19/2023 2:34:30 PM
 *  Author: sgeno
 */ 


#ifndef MASTER_I2C_H_
#define MASTER_I2C_H_


void I2C_Init();
uint8_t I2C_Start(char write_address);
uint8_t I2C_Repeated_Start(char read_address);
uint8_t I2C_Write(char data);
char I2C_Read_Ack();
char I2C_Read_Nack();
void I2C_Stop()	;

void I2C_Slave_Init(uint8_t slave_address);
int8_t I2C_Slave_Listen();
int8_t I2C_Slave_Transmit(char data);
char I2C_Slave_Receive();

#endif /* MASTER_I2C_H_ */
