/*
 * MPU6050_REG.c
 *
 * Created: 6/1/2023 9:20:08 PM
 *  Author: sgeno
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>

#include "MASTER_I2C.h"


#define MPU6050_ADDRESS 0x68

void I2C_Starter()
{
	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT)));
}

void MPU6050_Init()
{
	// Inicializar el MPU6050
	I2C_Starter();
	I2C_Write(MPU6050_ADDRESS << 1);
	I2C_Write(0x6B); // Registro PWR_MGMT_1
	I2C_Write(0x00); // Desactivar el modo de reposo
	I2C_Stop();
}

int16_t MPU6050_ReadRawData(uint8_t reg)
{
	int16_t value;

	I2C_Starter();
	I2C_Write(MPU6050_ADDRESS << 1);
	I2C_Write(reg);
	I2C_Starter();
	I2C_Write((MPU6050_ADDRESS << 1) | 1);
	value = (I2C_Read_Ack() << 8);
	value |= I2C_Read_Nack();
	I2C_Stop();

	return value;
}