/*
 * LCD_1602lib.c
 *
 * Created: 5/13/2023 3:39:04 PM
 *  Author: sgeno
 */ 

#define F_CPU 16000000UL			
#include <avr/io.h>			
#include <util/delay.h>

#define LCD_Dir  DDRD			/* Define LCD data port direction */
#define LCD_Port PORTD			/* Define LCD data port */
#define RS PD2					/* Define Register Select pin */
#define EN PD3					/* Define Enable Select pin */

void LCD_Command( unsigned char cmnd )
{
	LCD_Port = (LCD_Port & 0x0F) | (cmnd & 0xF0);	 /* sending upper nibble */
	LCD_Port &= ~ (1<<RS);							/* RS=0, command reg. */
	LCD_Port |= (1<<EN);							/* Enable pulse */
	_delay_us(1);
	LCD_Port &= ~ (1<<EN);

	_delay_us(200);

	LCD_Port = (LCD_Port & 0x0F) | (cmnd << 4);		/* sending lower nibble */
	LCD_Port |= (1<<EN);
	_delay_us(1);
	LCD_Port &= ~ (1<<EN);
	_delay_ms(2);
}

void LCD_Char( unsigned char data )
{
	LCD_Port = (LCD_Port & 0x0F) | (data & 0xF0);	 /* sending upper nibble */
	LCD_Port |= (1<<RS);							/* RS=1, data reg. */
	LCD_Port|= (1<<EN);
	_delay_us(1);
	LCD_Port &= ~ (1<<EN);

	_delay_us(200);

	LCD_Port = (LCD_Port & 0x0F) | (data << 4);		/* sending lower nibble */
	LCD_Port |= (1<<EN);
	_delay_us(1);
	LCD_Port &= ~ (1<<EN);
	_delay_ms(2);
}

void LCD_Init (void)				/* LCD Initialize function */
{
	LCD_Dir = 0xFF;					/* Make LCD port direction as o/p */
	_delay_ms(20);					/* LCD Power ON delay always >15ms */
	
	LCD_Command(0x02);				/* send for 4 bit initialization of LCD  */
	LCD_Command(0x28);              /* 2 line, 5*7 matrix in 4-bit mode */
	LCD_Command(0x0c);              /* Display on cursor off*/
	LCD_Command(0x06);              /* Increment cursor (shift cursor to right)*/
	LCD_Command(0x01);              /* Clear display screen*/
	_delay_ms(2);
}

void LCD_String (char *str)			/* Send string to LCD function */
{
	int i;
	for(i=0;str[i]!=0;i++)			/* Send each char of string till the NULL */
	{
		LCD_Char (str[i]);
	}
}

void LCD_String_xy (char row, char pos, char *str)	/* Send string to LCD with xy position */
{
	if (row == 0 && pos<16)
	LCD_Command((pos & 0x0F)|0x80);				/* Command of first row and required position<16 */
	else if (row == 1 && pos<16)
	LCD_Command((pos & 0x0F)|0xC0);				/* Command of first row and required position<16 */
	LCD_String(str);							/* Call LCD string function */
}

void LCD_Clear()
{
	LCD_Command (0x01);		/* Clear display */
	_delay_ms(2);
	LCD_Command (0x80);		/* Cursor at home position */
}

void LCD_Custom_Char (unsigned char loc, unsigned char *msg)
{
	unsigned char i;
	if(loc<8)
	{
		LCD_Command (0x40 + (loc*8));		/* Command 0x40 and onwards forces the device to point CGRAM address */
		for(i=0;i<8;i++)					/* Write 8 byte for generation of 1 character */
		LCD_Char(msg[i]);
	}
}

void LCD_Build_Char()
{
	unsigned char Character1[8] = { 0x00, 0x00, 0x04, 0x0E, 0x1F, 0x15, 0x04, 0x00 };  //
	unsigned char Character2[8] = { 0x06, 0x0C, 0x1F, 0x0C, 0x06, 0x00, 0x00, 0x00 };
	unsigned char Character3[8] = { 0x0C, 0x06, 0x1F, 0x06, 0x0C, 0x00, 0x00, 0x00 };
	unsigned char Character4[8] = { 0x00, 0x00, 0x00, 0x04, 0x15, 0x1F, 0x0E, 0x04 };
	unsigned char Character5[8] = { 0x07, 0x07, 0x02, 0x03, 0x0E, 0x13, 0x11, 0x0E }; //CHAIR
	unsigned char Character6[8] = { 0x00, 0x00, 0x00, 0x10, 0x00, 0x10, 0x08, 0x0C }; //RUN
	unsigned char Character7[8] = { 0x02, 0x09, 0x05, 0x15, 0x15, 0x05, 0x09, 0x02 }; //ULTRASONICO
	//unsigned char Character7[8] = { 0x02, 0x02, 0x02, 0x10, 0x02, 0x10, 0x08, 0x0C }; //warming
	unsigned char Character8[8] = { 0x0E, 0x0A, 0x0A, 0x0A, 0x0A, 0x11, 0x11, 0x0E }; //TEMPERATURE
	
	LCD_Init();
	LCD_Custom_Char(0, Character1);  /* Build Character1 at position 0 */
	LCD_Custom_Char(1, Character2);  /* Build Character2 at position 1 */
	LCD_Custom_Char(2, Character3);  /* Build Character3 at position 2 */
	LCD_Custom_Char(3, Character4);  /* Build Character4 at position 3 */
	LCD_Custom_Char(4, Character5);  /* Build Character5 at position 4 */
	LCD_Custom_Char(5, Character6);  /* Build Character6 at position 5 */
	LCD_Custom_Char(6, Character7);  /* Build Character6 at position 6 */
	LCD_Custom_Char(7, Character8);  /* Build Character6 at position 7 */
	
}

void STARTING_SYS()
{
	for(int i=0;i<13;i++)
	{
		LCD_Command((i & 0x0F)|0xC0);
		LCD_Char(' ');
		LCD_Char(4);
		LCD_Char(5);
		_delay_ms(300);
	}
	LCD_String_xy(1,3,"WELCOME!");
}

void MODE_SELECT()
{
	LCD_Clear();
	LCD_String_xy(0,0,"CONTROL MODE");
	LCD_Command((13 & 0x0F)|0x80);
	LCD_Char(4);
	LCD_Command((14 & 0x0F)|0x80);
	LCD_Char(5);
	LCD_String_xy(1,0,"Manual | Auto");
}

void STATIC_SYS()
{
	//MOVIMIENTO X
	LCD_Command((1 & 0x0F)|0x80);	//forward
	LCD_Char(0);
	LCD_Command((1 & 0x0F)|0xC0);	//backward
	LCD_Char(3);
	//MOVIMIENTO Y
	LCD_Command((0 & 0x0F)|0xC0);	//left
	LCD_Char(1);
	LCD_Command((2 & 0x0F)|0xC0);	//right
	LCD_Char(2);
	
	//SIGNALS
	LCD_Command((3 & 0x0F)|0xC0);//temperature
	LCD_Char(7);
	LCD_String(":TEMP ");
	LCD_Char(6);
	LCD_String(":DIST");
	LCD_Command((3 & 0x0F)|0x80); //wheelchair
	LCD_String("PRESS START");
	LCD_Char(4);
	LCD_Char(5);
}

void DINAMIC_X (char move)
{
		if (move=='B')
		{
					LCD_Command((1 & 0x0F)|0x80);	//forward
					LCD_Char(' ');
					LCD_Command((1 & 0x0F)|0xC0);	//backward
					LCD_Char(3);
		}
		if (move=='F')
		{
					LCD_Command((1 & 0x0F)|0x80);	//forward
					LCD_Char(0);
					LCD_Command((1 & 0x0F)|0xC0);	//backward
					LCD_Char(' ');
		}
		
		if (move=='N')
		{
					LCD_Command((1 & 0x0F)|0x80);	//forward
					LCD_Char(' ');
					LCD_Command((1 & 0x0F)|0xC0);	//backward
					LCD_Char(' ');
		}

}

void DINAMIC_Y (char movee)
{
	if (movee=='R')
	{
					LCD_Command((0 & 0x0F)|0xC0);	//left
					LCD_Char(' ');
					LCD_Command((2 & 0x0F)|0xC0);	//right
					LCD_Char(2);
	}
if (movee=='L')
{
				LCD_Command((0 & 0x0F)|0xC0);	//left
				LCD_Char(1);
				LCD_Command((2 & 0x0F)|0xC0);	//right
				LCD_Char(' ');
}
if (movee=='N')
{
	LCD_Command((0 & 0x0F)|0xC0);	//left
	LCD_Char(' ');
	LCD_Command((2 & 0x0F)|0xC0);	//right
	LCD_Char(' ');
}
			
}